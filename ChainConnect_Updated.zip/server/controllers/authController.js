const { generateToken } = require('../utils/jwtUtils');
const { hashPassword, comparePassword } = require('../utils/hashUtils');
const { findUserByEmail, addUser } = require('../models/User');

const loginUser = async (req, res) => {
  const { email, password } = req.body;
  let user = findUserByEmail(email);

  if (!user) {
    const hashedPassword = await hashPassword(password);
    user = { email, password: hashedPassword };
    addUser(user);
  }

  const passwordMatch = await comparePassword(password, user.password);
  if (!passwordMatch) return res.status(400).json({ error: 'Invalid credentials' });

  const token = generateToken(user);
  res.json({ token, email: user.email });
};

module.exports = { loginUser };