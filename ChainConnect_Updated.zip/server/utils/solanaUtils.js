const { Connection, Keypair, PublicKey } = require('@solana/web3.js');

const connection = new Connection(process.env.SOLANA_RPC, 'confirmed');

const createWallet = () => {
  const keypair = Keypair.generate();
  return { publicKey: keypair.publicKey.toBase58() };
};

const getBalance = async (publicKey) => {
  const balance = await connection.getBalance(new PublicKey(publicKey));
  return balance / 1e9;
};

module.exports = { createWallet, getBalance };