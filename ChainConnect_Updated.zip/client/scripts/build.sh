#!/bin/bash
echo "Building client..."
npm run build