#!/bin/bash
echo "Starting client..."
npm start