# ChainConnect

ChainConnect is a Web3 social app built on Solana, featuring authentication, wallet integration, and an intuitive UI.

## Features
- User authentication (email/password)
- Solana wallet creation & balance check
- React frontend & Express backend

## Installation
```sh
cd server && npm install
cd ../client && npm install
```

## Running the App
```sh
cd server && npm start
cd client && npm start
```
